class StaticPagesController < ApplicationController

	def home
  end

  def academic
  end

  def contact
  end

end